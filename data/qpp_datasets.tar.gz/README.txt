DBpedia with property path queries : /DBpedia2016_0_1_10_path_v3_weight_loss

Wkidata with property path queries : /wikidata_0_1_10_v3_path_weight_loss

DBpedia without property path queries : /DBpedia2016_0_1_10_weight_loss

Wikidata without property path queries : wikidata_0_1_10_v2_weight_loss
